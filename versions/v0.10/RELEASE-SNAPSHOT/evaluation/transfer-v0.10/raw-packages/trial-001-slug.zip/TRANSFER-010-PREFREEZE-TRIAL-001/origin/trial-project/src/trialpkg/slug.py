"""Slug normalization utility."""


def normalize_slug(text: str) -> str:
    """Return a stable URL-style slug for *text*."""
    raise NotImplementedError("transfer trial task not implemented")
