"""Slug normalization utility."""

import re
import unicodedata


def normalize_slug(text: str) -> str:
    """Return a stable URL-style slug for *text*."""
    ascii_text = (
        unicodedata.normalize("NFKD", text)
        .encode("ascii", "ignore")
        .decode("ascii")
        .lower()
    )
    return re.sub(r"[^a-z0-9]+", "-", ascii_text).strip("-")
