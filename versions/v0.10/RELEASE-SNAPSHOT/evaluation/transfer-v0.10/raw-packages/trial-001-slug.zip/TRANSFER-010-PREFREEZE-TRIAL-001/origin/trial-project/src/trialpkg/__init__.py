from .slug import normalize_slug

__all__ = ["normalize_slug"]
