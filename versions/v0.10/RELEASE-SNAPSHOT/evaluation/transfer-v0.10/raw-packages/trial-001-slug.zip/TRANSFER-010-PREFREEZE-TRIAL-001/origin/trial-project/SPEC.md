# Transfer Trial Slug Utility Specification

Project ID: TRANSFER-SLUG-UTILITY-001
Requirement ID: REQ-TRANSFER-SLUG-001

## Objective
Implement `normalize_slug(text: str) -> str` in `src/trialpkg/slug.py`.

## Frozen acceptance criteria
1. Return a lowercase ASCII slug.
2. Convert Unicode letters to their closest ASCII form using Python standard-library facilities (for example, `"Café"` becomes `"cafe"`).
3. Replace each run of non-ASCII-alphanumeric characters with exactly one hyphen.
4. Strip leading and trailing hyphens.
5. Return the empty string for empty input or input containing no ASCII alphanumeric characters after normalization.
6. Preserve the public function signature `normalize_slug(text: str) -> str`.
7. Add no third-party dependency.
8. Modify no file other than `src/trialpkg/slug.py`.

## Verification
The task passes only when `python -m pytest -q` exits 0 without changing tests or configuration.

## Failure behavior
Any failing test, added dependency, altered public signature, modification outside the authorized source file, or unreported missing information is a failure.
