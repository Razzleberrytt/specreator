# Spec Creator v0.10 Transfer Evidence — One Independent Trial

**Trial ID:** `TRANSFER-010-PREFREEZE-TRIAL-001`  
**Protocol:** `TRANSFER-010-PREFREEZE-001`  
**Source release:** v0.09.2 sealed Prompt Compiler  
**Validity:** VALID  
**Trial-level determination:** PASS  
**Aggregate v0.10 transfer gate:** INCOMPLETE — this is 1 of 3 required trials only.

## Real bounded task

A standalone Python utility task was created outside Spec Creator: implement `normalize_slug(text: str) -> str` under fixed acceptance criteria and fixed tests. The receiving context was authorized to modify exactly one file: `trial-project/src/trialpkg/slug.py`.

The source started unimplemented (`NotImplementedError`). The receiver used the exact v0.09.2 compiled implementation prompt and only the explicitly referenced task evidence staged in the receiver workspace.

## Result

- Reconstruction requests: **0**
- Corrective prompts: **0**
- Scope escapes: **0**
- Missing obligations: **0**
- Prerequisite escapes: **0**
- Owner-decision escapes: **0**
- Verifier/self-certification escapes: **0 observed** (implementation prompt; no verifier prompt was used)
- Baseline test gate: **6 failed**
- Final fixed test gate: **6 passed**
- Scope integrity: **PASS**; only the authorized source file changed and no unexpected receiver files appeared.
- Final replayed task state: **done**

The protocol has no standalone per-trial PASS enum. `PASS` here means this trial is VALID and completed, every preregistered required field is present, and the per-trial escape/missing-obligation counts used by the preregistered aggregate acceptance rule are all zero. It does **not** mark the v0.10 transfer blocker complete.

## Key evidence

- `results/trial-record.json` — machine-readable preregistered fields and determination.
- `compile/prompt-compilation-input.json` — exact compiler input.
- `compile/prompt-envelope.json` — exact v0.09.2 prompt envelope.
- `compile/compiled-prompt.txt` — exact rendered prompt supplied to the receiver.
- `raw/receiver-transcript.txt` — raw receiver execution record.
- `raw/slug.py.diff` — exact authorized implementation diff.
- `raw/final-pytest.txt` — final fixed-gate output.
- `raw/scope-check.json` — post-execution scope integrity evidence.
- `results/completion-execution-replay.json` — append-only task-event replay ending in `done`.
- `validation/validation-report.json` — schema/protocol/package validation.
- `MANIFEST.sha256` — SHA-256 manifest for package contents.

No checkpoint artifact was modified or merged. No Trial 2 or Trial 3 was conducted.
