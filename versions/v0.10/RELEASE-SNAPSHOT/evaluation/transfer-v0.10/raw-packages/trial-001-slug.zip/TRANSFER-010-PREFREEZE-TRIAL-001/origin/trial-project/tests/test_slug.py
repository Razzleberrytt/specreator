from trialpkg.slug import normalize_slug


def test_ascii_words_and_punctuation():
    assert normalize_slug("Hello, World!") == "hello-world"


def test_unicode_is_transliterated_with_stdlib_normalization():
    assert normalize_slug("  Café au Lait!  ") == "cafe-au-lait"


def test_runs_of_separators_collapse_to_one_hyphen():
    assert normalize_slug("alpha___beta   gamma") == "alpha-beta-gamma"


def test_leading_and_trailing_separators_are_removed():
    assert normalize_slug("---Alpha Beta---") == "alpha-beta"


def test_empty_and_punctuation_only_inputs():
    assert normalize_slug("") == ""
    assert normalize_slug("... -- !!!") == ""


def test_digits_are_preserved():
    assert normalize_slug("Version 2.0") == "version-2-0"
