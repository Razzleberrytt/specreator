from __future__ import annotations
import json, hashlib, os, re, shutil, subprocess, sys
from pathlib import Path
from collections import defaultdict, deque
from datetime import datetime, timezone
import jsonschema

ROOT=Path(sys.argv[1]).resolve()
OUT=Path(sys.argv[2]).resolve()
OUT.mkdir(parents=True, exist_ok=True)
V=ROOT/'versions'/'v0.11.1'
OLD=ROOT/'versions'/'v0.11'

def jload(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def jl(p): return [json.loads(x) for x in Path(p).read_text(encoding='utf-8').splitlines() if x.strip()]
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(name,obj):
    (OUT/name).write_text(json.dumps(obj,indent=2,sort_keys=False)+"\n",encoding='utf-8')

def transient(rel:Path):
    return any(x in {'.pytest_cache','__pycache__'} for x in rel.parts) or rel.suffix=='.pyc'

def package_paths():
    return sorted(p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and not transient(p.relative_to(ROOT)))

# 1 schemas and inherited semantic corpora
schema_files=[V/'candidate-schemas'/'execution-architecture-v1.candidate.schema.json',V/'candidate-schemas'/'lifecycle-checkpoint-v1.candidate.schema.json']
schema_results=[]
for p in schema_files:
    s=jload(p); err=None
    try: jsonschema.Draft202012Validator.check_schema(s)
    except Exception as e: err=repr(e)
    schema_results.append({'path':p.relative_to(ROOT).as_posix(),'draft202012_valid':err is None,'error':err})
life_schema=jload(schema_files[1]); checkpoint=jload(V/'LIFECYCLE-CHECKPOINT-DRAFT.json')
ck_errors=[{'path':list(e.path),'message':e.message} for e in jsonschema.Draft202012Validator(life_schema).iter_errors(checkpoint)]
exec_schema=jload(schema_files[0])
exec_task_schema=exec_schema['properties']['tasks']['items']
schema_semantic_guards={
 'execution_source_task_ids_required':'source_task_ids' in exec_task_schema['required'],
 'execution_source_task_ids_minItems':exec_task_schema['properties']['source_task_ids'].get('minItems'),
 'execution_integration_contract_required':'integration_contract' in exec_task_schema['required'],
 'lifecycle_transition_token_required':'transition_token' in life_schema['properties']['blockers']['items']['required'],
 'lifecycle_action_token_required':'action_token' in life_schema['properties']['next_legal_action']['required'],
}
semantic_assets=[
 'candidate-schemas/execution-architecture-v1.candidate.schema.json','candidate-schemas/lifecycle-checkpoint-v1.candidate.schema.json',
 'candidate-fixtures/execution-architecture-corpus.jsonl','candidate-fixtures/lifecycle-continuation-corpus.jsonl']
inherited=[]
for rel in semantic_assets:
    a=V/rel; b=OLD/rel
    inherited.append({'relative_asset':rel,'v011_sha256':sha(b),'v0111_sha256':sha(a),'byte_identical':a.read_bytes()==b.read_bytes()})
dump('schema-validation.json',{'schemas':schema_results,'lifecycle_checkpoint_errors':ck_errors,'semantic_guards':schema_semantic_guards,'inherited_semantic_assets':inherited})

# 2 lifecycle derivation independent from expected answers
rules=jload(V/'LIFECYCLE-TRANSITION-RULES.candidate.json')
life=jl(V/'candidate-fixtures'/'lifecycle-continuation-corpus.jsonl')
def pred_match(p, blockers):
    k=p['kind']
    if k=='empty': return len(blockers)==0
    if k=='nonempty': return len(blockers)>0
    if k=='contains_any': return any(t in blockers for t in p.get('tokens',[]))
    raise ValueError(k)
def resolve(state, blockers):
    hits=[r for r in rules['rules'] if r['state']==state and pred_match(r['blocker_predicate'],blockers)]
    if not hits: return {'error':'no_match','hits':[]}
    m=min(r['priority'] for r in hits); wins=[r for r in hits if r['priority']==m]
    if len(wins)!=1: return {'error':'priority_tie','hits':[r['rule_id'] for r in wins]}
    r=wins[0]; return {'action':r['action'],'rule_id':r['rule_id'],'priority':r['priority'],'all_matching_rules':[x['rule_id'] for x in hits]}
life_rows=[]
for f in life:
    got=resolve(f['state'],f['blockers'])
    life_rows.append({'fixture_id':f['fixture_id'],'state':f['state'],'blockers':f['blockers'],'derived':got,'authored_expected':f['expected_next_action'],'exact_match':got.get('action')==f['expected_next_action'],'hidden_reconstruction_derived':0})
open_tokens=[b['transition_token'] for b in checkpoint['blockers'] if b['status']=='OPEN']
ck_derived=resolve(checkpoint['release_state'],open_tokens)
dump('lifecycle-derivation.json',{'fixtures':life_rows,'fixture_pass_count':sum(x['exact_match'] for x in life_rows),'fixture_total':len(life_rows),'checkpoint':{'state':checkpoint['release_state'],'open_transition_tokens':open_tokens,'derived':ck_derived,'declared_action_token':checkpoint['next_legal_action']['action_token'],'exact_match':ck_derived.get('action')==checkpoint['next_legal_action']['action_token']}})

# 3 provenance/effective DAG/critical paths/waves/speculation/retry
prov=jload(V/'DEPENDENCY-PROVENANCE-RULES.candidate.json')
execfx=jl(V/'candidate-fixtures'/'execution-architecture-corpus.jsonl')
prov_rows=[]; struct=[]; explicit_all=[]; derived_all=[]; integration_keys=[]

def explicit_matches(tasks, producer_id, consumer):
    producer=tasks[producer_id]; m=[]
    if producer_id in consumer.get('authority_gates',[]): m.append('authority_gate')
    if set(producer.get('write',[])) & set(consumer.get('read',[])): m.append('artifact_input')
    if producer_id in consumer.get('integration_inputs',[]): m.append('explicit_integration')
    if producer_id in consumer.get('source_requirement_predecessors',[]): m.append('source_requirement')
    return m

def has_path(adj,a,b):
    q=[a]; seen={a}
    while q:
        x=q.pop()
        for y in adj.get(x,[]):
            if y==b:return True
            if y not in seen: seen.add(y); q.append(y)
    return False

def topo_waves(ids,edges):
    indeg={i:0 for i in ids}; adj=defaultdict(list)
    for a,b,_ in edges: indeg[b]+=1; adj[a].append(b)
    rem=set(ids); waves=[]
    while rem:
        ready=sorted(x for x in rem if indeg[x]==0)
        if not ready: raise RuntimeError('cycle')
        waves.append(ready)
        for x in ready:
            rem.remove(x)
            for y in adj[x]: indeg[y]-=1
    return waves

def all_max_paths(tasks,edges):
    ids=list(tasks); indeg={x:0 for x in ids}; pred=defaultdict(list); adj=defaultdict(list)
    for a,b,_ in edges: indeg[b]+=1; pred[b].append(a); adj[a].append(b)
    q=deque(sorted(x for x in ids if indeg[x]==0)); order=[]
    while q:
        x=q.popleft(); order.append(x)
        for y in sorted(adj[x]):
            indeg[y]-=1
            if indeg[y]==0:q.append(y)
    if len(order)!=len(ids): raise RuntimeError('cycle')
    best={}; paths={}
    for x in order:
        w=tasks[x]['w']
        if not pred[x]: best[x]=w; paths[x]=[(x,)]
        else:
            mx=max(best[p] for p in pred[x]); best[x]=mx+w
            paths[x]=[pp+(x,) for p in sorted(pred[x]) if best[p]==mx for pp in paths[p]]
    mx=max(best.values()); aps=sorted(set(p for x in ids if best[x]==mx for p in paths[x]))
    return [list(x) for x in aps],mx

for f in execfx:
    tasks={t['id']:t for t in f['tasks']}; ids=list(tasks); integration_keys += [f"{f['fixture_id']}::{i}" for i in ids]
    explicit=[]; base_adj=defaultdict(list)
    for consumer in f['tasks']:
        for d in consumer.get('deps',[]):
            ms=explicit_matches(tasks,d['task_id'],consumer)
            row={'fixture_id':f['fixture_id'],'edge':f"{d['task_id']}->{consumer['id']}",'declared':d['provenance'],'derived_matches':ms,'valid_exactly_one':len(ms)==1,'declared_matches_derived':len(ms)==1 and ms[0]==d['provenance']}
            prov_rows.append(row); explicit_all.append(f"{f['fixture_id']}::{d['task_id']}->{consumer['id']}")
            explicit.append((d['task_id'],consumer['id'],ms[0] if len(ms)==1 else 'INVALID')); base_adj[d['task_id']].append(consumer['id'])
    # mechanically derive minimal deterministic conflict serialization from declared order, only when unordered in explicit DAG
    derived=[]
    order=f.get('deterministic_conflict_order',[])
    if order:
        # conflict sets represented by ordered list; adjacent edge is minimum chain needed; ensure shared write and no preexisting path either direction
        for a,b in zip(order,order[1:]):
            shared=sorted(set(tasks[a].get('write',[])) & set(tasks[b].get('write',[])))
            pre_ab=has_path(base_adj,a,b); pre_ba=has_path(base_adj,b,a)
            if shared and not pre_ab and not pre_ba:
                derived.append((a,b,'conflict_serialization')); base_adj[a].append(b)
                derived_all.append(f"{f['fixture_id']}::{a}->{b}")
    edges=explicit+derived
    waves=topo_waves(ids,edges); cps,work=all_max_paths(tasks,edges)
    # unsafe parallelizations: same wave with reachability or write conflict
    adj=defaultdict(list)
    for a,b,_ in edges: adj[a].append(b)
    unsafe=[]
    for wi,w in enumerate(waves):
        for i,a in enumerate(w):
            for b in w[i+1:]:
                if has_path(adj,a,b) or has_path(adj,b,a) or (set(tasks[a].get('write',[])) & set(tasks[b].get('write',[]))): unsafe.append({'wave':wi,'a':a,'b':b})
    speculative=[t['id'] for t in f['tasks'] if t.get('speculative')]
    authority_escape=[]
    for t in f['tasks']:
        if t.get('speculative') and t.get('authoritative_before_prerequisites',False): authority_escape.append(t['id'])
    retry=None
    if 'failure_injection' in f:
        fail=f['failure_injection']['task_id']
        # rerun failed node and descendants; preserved = successful nodes outside that closure
        desc=set(); q=[fail]
        while q:
            x=q.pop()
            if x in desc: continue
            desc.add(x); q.extend(adj[x])
        preserve=sorted(set(ids)-desc)
        authored_preserve=sorted(f['expected'].get('must_preserve_after_B_failure',[]))
        unrelated=max(0,len(set(authored_preserve)&desc))
        retry={'failed_task':fail,'rerun_scope':sorted(desc),'preserve_successful_independent_work':preserve,'authored_must_preserve':authored_preserve,'preservation_exact':preserve==authored_preserve,'unrelated_rerun_count':unrelated,'authored_unrelated_rerun_count':f['expected'].get('unrelated_rerun_count')}
    struct.append({'fixture_id':f['fixture_id'],'effective_edges':[{'from':a,'to':b,'provenance':c} for a,b,c in edges], 'derived_conflict_edges':[f'{a}->{b}' for a,b,_ in derived], 'waves':waves,'authored_waves':f['expected']['waves'],'waves_exact':waves==f['expected']['waves'],'critical_paths':cps,'authored_critical_paths':f['expected']['critical_paths'],'critical_paths_exact':sorted(cps)==sorted(f['expected']['critical_paths']),'critical_work_units':work,'authored_critical_work_units':f['expected']['critical_work_units'],'critical_work_exact':work==f['expected']['critical_work_units'],'unsafe_parallelizations':unsafe,'speculative_tasks':speculative,'speculative_authority_escapes':authority_escape,'retry':retry})
dump('provenance-derivation.json',{'explicit_edges':prov_rows,'explicit_count':len(explicit_all),'exact_one_match_count':sum(x['valid_exactly_one'] for x in prov_rows),'declared_correct_count':sum(x['declared_matches_derived'] for x in prov_rows),'zero_match_count':sum(len(x['derived_matches'])==0 for x in prov_rows),'multi_match_count':sum(len(x['derived_matches'])>1 for x in prov_rows),'derived_conflict_edges':derived_all,'derived_conflict_count':len(derived_all),'effective_edge_count':len(explicit_all)+len(derived_all)})
dump('structural-recomputation.json',{'fixtures':struct,'wave_exact_pass_count':sum(x['waves_exact'] for x in struct),'critical_path_exact_pass_count':sum(x['critical_paths_exact'] and x['critical_work_exact'] for x in struct),'unsafe_parallelization_count':sum(len(x['unsafe_parallelizations']) for x in struct),'speculative_authority_escape_count':sum(len(x['speculative_authority_escapes']) for x in struct),'retry_isolation_pass':all((x['retry'] is None or (x['retry']['preservation_exact'] and x['retry']['unrelated_rerun_count']==x['retry']['authored_unrelated_rerun_count'])) for x in struct)})

# 4 universes exact derivation
u=jload(V/'EVALUATION-UNIVERSES.json')['universes']
all_eff=[]
for x in struct:
    all_eff += [f"{x['fixture_id']}::{e['from']}->{e['to']}" for e in x['effective_edges']]
uni_checks={
 'lifecycle_fixtures': u['lifecycle_fixtures']['members']==[f['fixture_id'] for f in life],
 'execution_fixtures': u['execution_fixtures']['members']==[f['fixture_id'] for f in execfx],
 'critical_path_fixtures_all_six': u['critical_path_fixtures']['members']==[f['fixture_id'] for f in execfx],
 'integration_source_tasks_fixed_23': u['integration_source_tasks']['members']==integration_keys and len(integration_keys)==23,
 'explicit_dependency_edges_21': u['explicit_dependency_edges']['members']==explicit_all and len(explicit_all)==21,
 'derived_conflict_edges_1': u['derived_conflict_edges']['members']==derived_all and len(derived_all)==1,
 'effective_dependency_edges_22': set(u['effective_dependency_edges']['members'])==set(all_eff) and len(all_eff)==22,
}
dump('universe-audit.json',{'checks':uni_checks,'derived_integration_source_tasks':integration_keys,'derived_explicit_edges':explicit_all,'derived_conflict_edges':derived_all,'derived_effective_edges':all_eff})

# 5 parent suite snapshot comparison (collection command output parsed independently; outcome handled separately by clean command)
parent=jload(V/'PARENT-SUITE-UNIVERSE.json')
cp=subprocess.run([sys.executable,'-m','pytest','--collect-only','-q'],cwd=ROOT,text=True,capture_output=True)
nodeids=[ln.strip() for ln in cp.stdout.splitlines() if '::' in ln and not ln.startswith('=')]
dump('parent-suite-audit.json',{'collection_exit_code':cp.returncode,'fresh_count':len(nodeids),'expected_count':parent['expected_count'],'unique_count':len(set(nodeids)),'exact_order_match':nodeids==parent['nodeids'],'fresh_nodeids':nodeids})

# 6 regressions exact universe and inherited outcome evidence
ledger=[]
for r in jl(ROOT/'self-improvement'/'regressions.jsonl'):
    if r.get('status')=='active': ledger.append(r['regression_id'])
snap=jload(V/'ACTIVE-REGRESSION-UNIVERSE.json'); snapids=[r['regression_id'] for r in snap['regressions']]
scorecards=jl(ROOT/'evaluation'/'release-scorecards.jsonl'); sc=next((x for x in scorecards if x.get('candidate_version')=='0.10'),None)
sc_by={r['id']:r['status'] for r in sc.get('regression_outcomes',[])} if sc else {}
inh_out=[{'regression_id':rid,'v010_scorecard_status':sc_by.get(rid)} for rid in ledger]
# independent REG-0025 reproduction: old v0.11 exact successor mechanism against failed-v0.11 baseline-derived failed checkpoint universe
oldown=jload(OLD/'SUCCESSOR-OWNERSHIP-UNIVERSE.json'); oldset=set(oldown['members'])
failed=jload(V/'FAILED-PREDECESSOR-v0.11-BASELINE.json'); failedset={x['path'] for x in failed['entries']}
old_missing=sorted(failedset-oldset) # package manifest is old member but not failed baseline; 52 later v0.11 paths are absent
reg0025={'old_successor_member_count':len(oldset),'failed_v011_baseline_member_count':len(failedset),'failed_baseline_members_not_admitted_by_old_exact_successor':old_missing,'reproduced_unclassified_count':len(old_missing),'expected_defect_unclassified_count':52,'reproduction_pass':len(old_missing)==52}
dump('active-regression-audit.json',{'ledger_active_count':len(ledger),'ledger_active_ids':ledger,'snapshot_expected_count':snap['expected_count'],'snapshot_ids':snapids,'inherited_24_exact_order_match':snapids[:24]==ledger and len(ledger)==24,'retry_local_tail_exact':snapids[24:]==['REG-0025'],'v010_inherited_outcomes':inh_out,'v010_24_pass':len(inh_out)==24 and all(x['v010_scorecard_status']=='PASS' for x in inh_out),'reg0025_failed_mechanism_reproduction':reg0025})

# 7 hashes and classification
man=jload(ROOT/'versions'/'v0.10'/'MANIFEST.json'); m=man['content_hashes']
parent_hash_rows=[]
for rel,exp in m.items():
    p=ROOT/rel; act=sha(p) if p.is_file() else None
    parent_hash_rows.append({'path':rel,'expected_sha256':exp,'actual_sha256':act,'match':act==exp})
failed_rows=[]
for item in failed['entries']:
    p=ROOT/item['path']; raw=p.read_bytes() if p.is_file() else None
    failed_rows.append({'path':item['path'],'expected_sha256':item['sha256'],'actual_sha256':hashlib.sha256(raw).hexdigest() if raw is not None else None,'expected_bytes':item['bytes'],'actual_bytes':len(raw) if raw is not None else None,'match':raw is not None and hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['bytes']})
dump('hash-integrity.json',{'v010_manifest_entry_count':len(m),'v010_match_count':sum(x['match'] for x in parent_hash_rows),'v010_mismatches':[x for x in parent_hash_rows if not x['match']],'v010_entries':parent_hash_rows,'failed_v011_entry_count':len(failed_rows),'failed_v011_match_count':sum(x['match'] for x in failed_rows),'failed_v011_mismatches':[x for x in failed_rows if not x['match']],'failed_v011_entries':failed_rows})

reg=jload(V/'IMMUTABILITY-BOUNDARY-DRAFT.json'); own=jload(V/'SUCCESSOR-OWNERSHIP-UNIVERSE.json')
protected=set(m)|set(reg['protected_release_manifests'])

def smatch(rel,s):
    k=s['kind']
    if k=='exact': return rel==s['value']
    if k=='prefix': return rel.startswith(s['value'])
    if k=='directory_filename_prefix':
        if not rel.startswith(s['directory']): return False
        tail=rel[len(s['directory']):]; return '/' not in tail and tail.startswith(s['value'])
    if k=='directory_filename_in':
        if not rel.startswith(s['directory']): return False
        tail=rel[len(s['directory']):]; return '/' not in tail and tail in set(s['values'])
    raise ValueError(k)
paths=package_paths(); classrows=[]; un=[]; overlap=[]; multi=[]; succ=[]; failover=[]
for rel in paths:
    matches=[s['selector_id'] for s in own['selectors'] if smatch(rel,s)]
    if rel in protected:
        cls='IMMUTABLE_PARENT_V010'
        if matches: overlap.append({'path':rel,'matches':matches})
    elif rel in failedset:
        cls='IMMUTABLE_FAILED_PREDECESSOR_V011'
        if matches: overlap.append({'path':rel,'matches':matches})
    else:
        if len(matches)==1: cls='MUTABLE_RETRY_SUCCESSOR'; succ.append(rel)
        elif len(matches)==0: cls='UNCLASSIFIED'; un.append(rel)
        else: cls='MULTIMATCH'; multi.append({'path':rel,'matches':matches})
    classrows.append({'path':rel,'class':cls,'successor_selector_matches':matches})
snapshot=set(own['current_snapshot_members']); stale=sorted(snapshot-set(paths)); snap_missing=sorted(set(succ)-snapshot); snap_extra=sorted(snapshot-set(succ))
dump('whole-package-classification.json',{'shipped_file_count':len(paths),'protected_parent_count':len(protected),'failed_predecessor_count':len(failedset),'retry_successor_count':len(succ),'unclassified_count':len(un),'immutable_successor_overlap_count':len(overlap),'successor_selector_multi_match_count':len(multi),'stale_snapshot_member_count':len(stale),'snapshot_missing_current_successors':snap_missing,'snapshot_extra_vs_current_successors':snap_extra,'snapshot_exact_current_successor_set':snapshot==set(succ),'protected_failed_overlap_count':len(protected&failedset),'unclassified':un,'overlaps':overlap,'multimatches':multi,'stale_snapshot_members':stale,'classifications':classrows})

# 8 prospective closure
pros=jload(V/'candidate-fixtures'/'ownership-prospective-paths.json')
legal=[]
for rel in pros['members']:
    ms=[s['selector_id'] for s in own['selectors'] if smatch(rel,s)]
    ok=rel not in protected and rel not in failedset and len(ms)==1
    legal.append({'path':rel,'matches':ms,'pass':ok})
forbidden=[]
for rel in pros['forbidden_members']:
    ms=[s['selector_id'] for s in own['selectors'] if smatch(rel,s)]
    forbidden.append({'path':rel,'matches':ms,'pass':len(ms)==0})
dump('prospective-output-closure.json',{'legal_count':len(legal),'legal_pass_count':sum(x['pass'] for x in legal),'legal_results':legal,'forbidden_count':len(forbidden),'forbidden_pass_count':sum(x['pass'] for x in forbidden),'forbidden_results':forbidden})

# 9 prereg hash inventory
inv=jload(V/'PREREGISTRATION-ARTIFACT-HASHES-DRAFT.json')
expected=[]
for p in sorted(V.rglob('*')):
    if p.is_file() and p.name!='PREREGISTRATION-ARTIFACT-HASHES-DRAFT.json' and not transient(p.relative_to(ROOT)):
        expected.append(p.relative_to(ROOT).as_posix())
invrows=[]
for item in inv['artifacts']:
    p=ROOT/item['path']; raw=p.read_bytes() if p.is_file() else None
    invrows.append({'path':item['path'],'hash_match':raw is not None and hashlib.sha256(raw).hexdigest()==item['sha256'],'bytes_match':raw is not None and len(raw)==item['bytes']})
dump('preregistration-hash-audit.json',{'declared_count':inv['artifact_count'],'listed_count':len(inv['artifacts']),'expected_current_v0111_nonself_count':len(expected),'path_order_exact': [x['path'] for x in inv['artifacts']]==expected,'hash_match_count':sum(x['hash_match'] and x['bytes_match'] for x in invrows),'rows':invrows})

# 10 metric nonweakening: compare all 15 old metrics. Semantics changes only additive universe extensions for 3 inherited guardrails.
oldp=jload(OLD/'EVALUATION-PLAN.json'); newp=jload(V/'EVALUATION-PLAN.json')
oldm={x['metric']:x for x in oldp['primary_metrics']+oldp['guardrail_metrics']}; newm={x['metric']:x for x in newp['primary_metrics']+newp['guardrail_metrics']}
metricrows=[]
for name,om in oldm.items():
    nm=newm.get(name)
    row={'metric':name,'present':nm is not None}
    if nm:
        row.update({'old_target':om.get('target'),'new_target':nm.get('target'),'target_unchanged':om.get('target')==nm.get('target'),'old_universe':om.get('universe'),'new_universe':nm.get('universe'),'universe_name_unchanged':om.get('universe')==nm.get('universe'),'old_denominator_count':om.get('denominator_count'),'new_denominator_count':nm.get('denominator_count'),'old_numerator_rule':om.get('numerator_rule'),'new_numerator_rule':nm.get('numerator_rule'),'numerator_rule_unchanged':om.get('numerator_rule')==nm.get('numerator_rule')})
        if name in {'active_regression_pass_rate','missing_data_count','critical_gate_bypass_count'}:
            row['denominator_change_class']='additive_stricter'
            row['denominator_nonweaker']=(nm.get('denominator_count',0)>om.get('denominator_count',0))
        else:
            row['denominator_change_class']='unchanged'
            row['denominator_nonweaker']=om.get('denominator_count')==nm.get('denominator_count')
        # oracle ref version path is allowed only if semantic rule body unchanged after metadata normalization
        row['nonweaker']=row['target_unchanged'] and row['universe_name_unchanged'] and row['numerator_rule_unchanged'] and row['denominator_nonweaker']
    metricrows.append(row)
# universe extension exactness for 3 guards
oldu=jload(OLD/'EVALUATION-UNIVERSES.json')['universes']
extensions={}
for uname in ['active_regressions','mandatory_evidence_slots','mandatory_quality_gates']:
    if uname=='active_regressions':
        a=ledger[:]
        b=snapids[:]
    else:
        a=oldu[uname]['members']
        b=u[uname]['members']
    extensions[uname]={'old_count':len(a),'new_count':len(b),'old_prefix_preserved':b[:len(a)]==a,'added_members':b[len(a):]}
# global anti-gaming/missing data controls exact
control_keys=['missing_data_policy','structural_vs_empirical_rule','control_equivalence_rule','integration_anti_gaming_rule','critical_path_tie_rule','promotion_ceiling']
controls={k:{'old':oldp.get(k),'new':newp.get(k),'unchanged':oldp.get(k)==newp.get(k)} for k in control_keys}
new_only=sorted(set(newm)-set(oldm))
dump('metric-nonweakening.json',{'old_promotion_authoritative_metric_count':oldp['promotion_authoritative_metric_count'],'new_promotion_authoritative_metric_count':newp['promotion_authoritative_metric_count'],'inherited_metric_rows':metricrows,'all_15_nonweaker':len(metricrows)==15 and all(x.get('nonweaker') for x in metricrows),'additive_universe_extensions':extensions,'global_controls':controls,'all_global_controls_unchanged':all(x['unchanged'] for x in controls.values()),'new_only_metrics':new_only,'additive_guardrail_valid':new_only==['prospective_output_classification_error_count'] and newm['prospective_output_classification_error_count'].get('target')==0,'retry_nonweakening_rule':newp.get('retry_nonweakening_rule')})

# 11 package manifest check (self manifest covers every non-self file)
pm=jload(ROOT/'PACKAGE-MANIFEST.json'); content=pm.get('content_hashes',{})
# package manifest structure may differ; derive if content_hashes exists, else inspect files array
pmres={'keys':list(pm.keys())}
if content:
    nonself=set(paths)-{'PACKAGE-MANIFEST.json'}; listed=set(content)
    mism=[]
    for rel,exp in content.items():
        p=ROOT/rel; act=sha(p) if p.is_file() else None
        if act!=exp:mism.append({'path':rel,'expected':exp,'actual':act})
    pmres.update({'mode':'content_hashes','nonself_count':len(nonself),'listed_count':len(listed),'missing':sorted(nonself-listed),'stale':sorted(listed-nonself),'mismatch_count':len(mism),'mismatches':mism,'pass':nonself==listed and not mism})
else:
    # current package format contains generated_at etc and files list
    arr=pm.get('files',[]); listed={x['path'] for x in arr}; nonself=set(paths)-{'PACKAGE-MANIFEST.json'}; mism=[]
    for x in arr:
        p=ROOT/x['path']; raw=p.read_bytes() if p.is_file() else None
        if raw is None or hashlib.sha256(raw).hexdigest()!=x.get('sha256') or len(raw)!=x.get('bytes'): mism.append({'path':x['path']})
    pmres.update({'mode':'files','nonself_count':len(nonself),'listed_count':len(listed),'missing':sorted(nonself-listed),'stale':sorted(listed-nonself),'mismatch_count':len(mism),'mismatches':mism,'pass':nonself==listed and not mism})
dump('package-manifest-validation.json',pmres)

# aggregate decision based only on independent evidence generated above; validation commands handled externally
obligations={
 'schemas_and_semantic_corpora': all(x['draft202012_valid'] for x in schema_results) and not ck_errors and all(x['byte_identical'] for x in inherited) and all(schema_semantic_guards.values()),
 'lifecycle_actions': all(x['exact_match'] for x in life_rows) and ck_derived.get('action')==checkpoint['next_legal_action']['action_token'],
 'provenance_and_execution': len(explicit_all)==21 and all(x['valid_exactly_one'] and x['declared_matches_derived'] for x in prov_rows) and len(derived_all)==1 and all(x['waves_exact'] and x['critical_paths_exact'] and x['critical_work_exact'] for x in struct) and sum(len(x['unsafe_parallelizations']) for x in struct)==0 and sum(len(x['speculative_authority_escapes']) for x in struct)==0 and all(x['retry'] is None or x['retry']['preservation_exact'] for x in struct) and len(integration_keys)==23,
 'parent_suite_collection': cp.returncode==0 and len(nodeids)==155 and nodeids==parent['nodeids'],
 'regression_universe': len(ledger)==24 and snapids[:24]==ledger and snapids[24:]==['REG-0025'] and all(x['v010_scorecard_status']=='PASS' for x in inh_out) and reg0025['reproduction_pass'],
 'historical_hashes': len(m)==1120 and all(x['match'] for x in parent_hash_rows) and len(failed_rows)==154 and all(x['match'] for x in failed_rows),
 'whole_package_ownership': len(protected)==1121 and len(failedset)==154 and len(succ)==36 and not un and not overlap and not multi and not stale and snapshot==set(succ) and not (protected&failedset),
 'prospective_paths': len(legal)==25 and all(x['pass'] for x in legal) and len(forbidden)==7 and all(x['pass'] for x in forbidden),
 'metric_nonweakening': len(metricrows)==15 and all(x.get('nonweaker') for x in metricrows) and all(x['unchanged'] for x in controls.values()) and new_only==['prospective_output_classification_error_count'] and newm['prospective_output_classification_error_count'].get('target')==0,
 'preregistration_hash_inventory': inv['artifact_count']==len(inv['artifacts'])==len(expected) and [x['path'] for x in inv['artifacts']]==expected and all(x['hash_match'] and x['bytes_match'] for x in invrows),
 'package_manifest': pmres.get('pass') is True,
}
dump('review-obligations-precommands.json',{'obligations':obligations,'all_pass':all(obligations.values()),'generated_at_utc':datetime.now(timezone.utc).isoformat()})
print(json.dumps({'all_precommand_obligations_pass':all(obligations.values()),'obligations':obligations,'counts':{'package_files':len(paths),'protected':len(protected),'failed_predecessor':len(failedset),'retry_successor':len(succ),'parent_tests':len(nodeids),'active_regressions':len(snapids),'v010_hashes':sum(x['match'] for x in parent_hash_rows),'failed_v011_hashes':sum(x['match'] for x in failed_rows),'prospective_legal_pass':sum(x['pass'] for x in legal)}},indent=2))
