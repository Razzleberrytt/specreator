# Spec Creator v0.10 Transfer Trial Evidence Package

Trial: `TRANSFER-010-TRIAL-001-RX-001`
Protocol: `TRANSFER-010-PREFREEZE-001`
Source release: v0.09.2 Prompt Compiler

This package contains evidence for exactly one separate-context real-task transfer trial. It does not modify or advance Spec Creator v0.10.

The software task was a bounded standalone Python CLI that generates deterministic SHA-256 directory manifests. The exact compiled prompt, compiler input/envelope, originating compiled task graph, supplied evidence, implementation result, raw observable transcript, completion evidence, validation report, and provenance are all included.

`trial-record.json` is the machine-readable ingestion record.
