from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: TEST-TRIAL-001.py IMPLEMENTATION", file=sys.stderr)
        return 2
    implementation = Path(sys.argv[1]).resolve()
    if not implementation.is_file():
        print(f"missing implementation: {implementation}", file=sys.stderr)
        return 1

    with tempfile.TemporaryDirectory() as td:
        root = Path(td) / "input"
        root.mkdir()
        (root / "b.txt").write_bytes(b"beta\n")
        (root / "a").mkdir()
        (root / "a" / "alpha.bin").write_bytes(b"\x00alpha\xff")
        (root / "empty").write_bytes(b"")
        output = root / "nested" / "manifest.json"

        cmd = [sys.executable, str(implementation), str(root), str(output)]
        first = subprocess.run(cmd, capture_output=True, text=True)
        if first.returncode != 0:
            print(first.stdout, end="")
            print(first.stderr, end="", file=sys.stderr)
            print(f"first run exit={first.returncode}", file=sys.stderr)
            return 1
        first_bytes = output.read_bytes()

        second = subprocess.run(cmd, capture_output=True, text=True)
        if second.returncode != 0:
            print(second.stdout, end="")
            print(second.stderr, end="", file=sys.stderr)
            print(f"second run exit={second.returncode}", file=sys.stderr)
            return 1
        second_bytes = output.read_bytes()
        if first_bytes != second_bytes:
            print("output is not byte-deterministic", file=sys.stderr)
            return 1

        payload = json.loads(first_bytes.decode("utf-8"))
        if set(payload) != {"schema_version", "files"} or payload["schema_version"] != "1.0":
            print(f"unexpected top-level payload: {payload!r}", file=sys.stderr)
            return 1
        rows = payload["files"]
        paths = [row["path"] for row in rows]
        expected_paths = ["a/alpha.bin", "b.txt", "empty"]
        if paths != expected_paths:
            print(f"paths mismatch: {paths!r} != {expected_paths!r}", file=sys.stderr)
            return 1
        if "nested/manifest.json" in paths:
            print("output self-included", file=sys.stderr)
            return 1

        expected = {
            "a/alpha.bin": b"\x00alpha\xff",
            "b.txt": b"beta\n",
            "empty": b"",
        }
        for row in rows:
            if set(row) != {"path", "sha256", "size_bytes"}:
                print(f"unexpected row keys: {row!r}", file=sys.stderr)
                return 1
            data = expected[row["path"]]
            if row["sha256"] != sha(data):
                print(f"sha mismatch for {row['path']}", file=sys.stderr)
                return 1
            if row["size_bytes"] != len(data):
                print(f"size mismatch for {row['path']}", file=sys.stderr)
                return 1

    print("TEST-TRIAL-001 PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
