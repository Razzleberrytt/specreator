from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_manifest(target: Path, output: Path) -> dict[str, object]:
    target = target.resolve()
    output = output.resolve()

    rows: list[dict[str, object]] = []
    for path in target.rglob("*"):
        if not path.is_file():
            continue
        resolved = path.resolve()
        if resolved == output:
            continue
        relative = path.relative_to(target).as_posix()
        rows.append(
            {
                "path": relative,
                "sha256": file_sha256(path),
                "size_bytes": path.stat().st_size,
            }
        )

    rows.sort(key=lambda row: str(row["path"]))
    return {"schema_version": "1.0", "files": rows}


def main(argv: list[str]) -> int:
    if len(argv) != 3:
        print("usage: evidence_hash_manifest.py TARGET OUTPUT", file=sys.stderr)
        return 2

    target = Path(argv[1])
    output = Path(argv[2])
    if not target.is_dir():
        print(f"TARGET is not a directory: {target}", file=sys.stderr)
        return 2

    payload = build_manifest(target, output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
