# GATE-TRIAL-001

PASS requires all of the following:
- `python receiver/evidence/TEST-TRIAL-001.py receiver/trial_project/evidence_hash_manifest.py` exits with code 0.
- The implementation source exists and is a regular file.
- The supplied evidence directory is byte-identical before and after the implementation window.
- No implementation-time file creation/modification occurs under `receiver/trial_project/` except `evidence_hash_manifest.py`.

Otherwise the gate is FAIL.
