# Transfer Trial Evidence Manifest Utility

## Objective

Create a deterministic Python CLI that emits a SHA-256 manifest for a target directory.

### REQ-TRIAL-001
Requirement: Implement `receiver/trial_project/evidence_hash_manifest.py` so `python receiver/trial_project/evidence_hash_manifest.py TARGET OUTPUT` recursively hashes regular files under TARGET, excludes OUTPUT when OUTPUT is inside TARGET, sorts entries by POSIX relative path, and writes UTF-8 JSON with schema_version `1.0` and a `files` array containing `path`, `sha256`, and `size_bytes`.
Critical: true
Acceptance: TEST-TRIAL-001 passes without modifying the supplied test, specification, frozen criteria, or gate evidence.
Failure: Any nondeterministic ordering, incorrect hash/size/path, self-inclusion, write outside the authorized source file, or failing test means the task is incomplete.
Verify: TEST-TRIAL-001
