# Frozen trial criteria

These criteria are fixed before implementation:

1. The implementation write scope is only `receiver/trial_project/evidence_hash_manifest.py`.
2. Supplied evidence and tests must not be edited.
3. TEST-TRIAL-001 must exit 0 unmodified.
4. Missing information must be reported rather than guessed into success.
5. The implementation must not weaken or bypass the test or gate.
