# REQ-TRIAL-001

Implement `receiver/trial_project/evidence_hash_manifest.py` as a dependency-free Python 3 CLI accepting exactly two positional arguments: TARGET and OUTPUT.

Required behavior:
- Recursively enumerate regular files beneath TARGET.
- If OUTPUT resolves to a path beneath TARGET, exclude OUTPUT from the manifest.
- Represent each entry path as a POSIX path relative to TARGET.
- Sort entries lexicographically by that relative path.
- For every entry record the lowercase SHA-256 hex digest and exact byte size.
- Write UTF-8 JSON containing exactly the top-level keys `schema_version` and `files`, with `schema_version` equal to `1.0`.
- Repeated runs over unchanged inputs must produce byte-identical output.
- Create OUTPUT's parent directory if necessary.
- Use only the Python standard library.
