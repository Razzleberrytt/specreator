# Transfer Evidence — One Trial Only

**Protocol:** TRANSFER-010-PREFREEZE-001  
**Trial:** TRANSFER-010-TRIAL-001-RETRY-AFTER  
**Source Prompt Compiler:** sealed v0.09.2  
**Validity:** VALID / COMPLETED  
**Individual PASS/FAIL:** not defined by the preregistered protocol; no individual PASS is asserted.  
**Aggregate v0.10 transfer gate:** still incomplete until three valid trials exist.

This ZIP contains evidence for exactly one separate-context real-task transfer trial. It does not modify or merge into the Spec Creator checkpoint and does not freeze, implement, promote, repair, or otherwise advance v0.10.

Key artifacts:
- `trial-record.json` — machine-readable preregistered fields and requested observations.
- `originating-task.json` — exact bounded task identity and pre-state references.
- `compiler-artifacts/prompt-compilation-input.json` — exact v0.09.2 Prompt Compiler input.
- `compiler-artifacts/prompt-envelope.json` — exact compiled envelope.
- `receiver-input/compiled-prompt.txt` — exact compiled prompt text delivered to the receiver.
- `raw-evidence/raw-trial-transcript.md` — observable execution record.
- `raw-evidence/pytest-before.txt` / `pytest-after.txt` — real baseline/completion outputs.
- `raw-evidence/project-hash-diff.json` — scope-retention evidence.
- `validation/final-validation-report.json` — frozen-schema and preregistered-field validation.
- `validation/source-release-provenance.json` — hashes identifying the sealed compiler/protocol sources used.
