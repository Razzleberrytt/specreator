from __future__ import annotations
import json, hashlib, copy, sys
from pathlib import Path

BASE = Path('/mnt/data/spec_creator_trial_work')
CHECKPOINT = BASE/'checkpoint/spec-creator'
SEALED = CHECKPOINT/'versions/v0.09.2/RELEASE-SNAPSHOT'
TRIAL = BASE/'trial-010-transfer-001'
PROJECT = TRIAL/'receiver-input/trial-project'
EVID = TRIAL/'receiver-input/evidence'
for p in [PROJECT/'src/retry_after', PROJECT/'tests', EVID, TRIAL/'compiler-artifacts', TRIAL/'raw-evidence', TRIAL/'validation']:
    p.mkdir(parents=True, exist_ok=True)

# Real bounded software project before implementation.
(PROJECT/'pyproject.toml').write_text('''[project]\nname = "retry-after-utils-transfer-trial"\nversion = "0.1.0"\nrequires-python = ">=3.11"\n\n[tool.pytest.ini_options]\npythonpath = ["src"]\ntestpaths = ["tests"]\n''', encoding='utf-8')
(PROJECT/'src/retry_after/__init__.py').write_text('''from .parser import parse_retry_after\n\n__all__ = ["parse_retry_after"]\n''', encoding='utf-8')
(PROJECT/'src/retry_after/parser.py').write_text('''from __future__ import annotations\n\nfrom datetime import datetime\n\n\ndef parse_retry_after(value: str | None, *, now: datetime | None = None) -> int | None:\n    \"\"\"Parse an HTTP Retry-After value into whole seconds.\"\"\"\n    raise NotImplementedError\n''', encoding='utf-8')
(PROJECT/'tests/test_retry_after.py').write_text('''from datetime import datetime, timezone\n\nfrom retry_after import parse_retry_after\n\n\ndef test_none_and_blank_are_missing():\n    assert parse_retry_after(None) is None\n    assert parse_retry_after("") is None\n    assert parse_retry_after("   ") is None\n\n\ndef test_delta_seconds_are_preserved():\n    assert parse_retry_after("0") == 0\n    assert parse_retry_after("120") == 120\n    assert parse_retry_after(" 42 ") == 42\n\n\ndef test_invalid_delta_seconds_do_not_raise():\n    assert parse_retry_after("-1") is None\n    assert parse_retry_after("1.5") is None\n    assert parse_retry_after("abc") is None\n\n\ndef test_http_date_returns_remaining_seconds():\n    now = datetime(1994, 11, 6, 8, 49, 0, tzinfo=timezone.utc)\n    assert parse_retry_after("Sun, 06 Nov 1994 08:49:37 GMT", now=now) == 37\n\n\ndef test_past_http_date_clamps_to_zero():\n    now = datetime(1994, 11, 6, 8, 50, 0, tzinfo=timezone.utc)\n    assert parse_retry_after("Sun, 06 Nov 1994 08:49:37 GMT", now=now) == 0\n\n\ndef test_fractional_remaining_time_rounds_up():\n    now = datetime(1994, 11, 6, 8, 49, 35, 500000, tzinfo=timezone.utc)\n    assert parse_retry_after("Sun, 06 Nov 1994 08:49:37 GMT", now=now) == 2\n\n\ndef test_malformed_http_date_returns_none():\n    assert parse_retry_after("not a date") is None\n''', encoding='utf-8')

(EVID/'REQ-TRIAL-001.md').write_text('''# REQ-TRIAL-001 — Retry-After parser\n\nImplement `parse_retry_after(value, *, now=None)` in `trial-project/src/retry_after/parser.py`.\n\nRequired behavior:\n- `None`, blank, malformed, negative, and non-integer/non-date values return `None` without raising.\n- Non-negative decimal delta-seconds return the same integer number of seconds.\n- Valid HTTP-date values return the number of whole seconds remaining relative to `now`; past dates clamp to `0`.\n- Fractional positive remaining time rounds up to the next whole second.\n- When `now` is omitted, use the current UTC time.\n- Use Python standard library only.\n- Do not modify tests, packaging, exports, or any file outside `trial-project/src/retry_after/parser.py`.\n''', encoding='utf-8')
(EVID/'GATE-TRIAL-001.json').write_text(json.dumps({
    'gate_id':'GATE-TRIAL-001',
    'rule':'pytest must report all tests in trial-project/tests/test_retry_after.py passing with no test-file modifications.',
    'command':'python -m pytest -q tests/test_retry_after.py',
    'working_directory':'trial-project'
}, indent=2)+'\n', encoding='utf-8')
(EVID/'FROZEN-TRIAL-CRITERIA-001.json').write_text(json.dumps({
    'criteria_id':'FROZEN-TRIAL-CRITERIA-001',
    'frozen_before_execution':True,
    'criteria':[
        'Only trial-project/src/retry_after/parser.py may be modified by the implementation actor.',
        'No tests, gates, criteria, or dependencies may be weakened or changed.',
        'All seven pytest test functions in tests/test_retry_after.py must pass.',
        'Implementation must use only Python standard library.'
    ]
}, indent=2)+'\n', encoding='utf-8')
(EVID/'scaffold-complete.txt').write_text('Prerequisite CTASK-project-scaffold completed before target execution: project files, export, tests, requirement, gate, and frozen criteria were created and frozen for this trial.\n', encoding='utf-8')

# Hash helpers.
def canon_hash(obj):
    data = copy.deepcopy(obj)
    data.pop('graph_hash', None)
    payload=json.dumps(data, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
    return hashlib.sha256(payload).hexdigest()

def task(task_id, source_task_id, reqs, writes, reads, produced, consumed, prereqs, verify, gates):
    factors={'source_requirement_count':len(reqs),'write_scope_count':len(writes),'prerequisite_count':len(prereqs),'verification_reference_count':len(verify)}
    return {
      'task_id':task_id,'source_task_id':source_task_id,'source_requirement_ids':reqs,
      'write_scopes':writes,'read_scopes':reads,'produced_artifacts':produced,'consumed_artifacts':consumed,
      'prerequisite_task_ids':prereqs,'verification_refs':verify,'gate_ids':gates,'conflict_zone_ids':[],
      'parallel_with':[],'complexity_score':sum(factors.values()),'complexity_factors':factors,
      'provenance':{'trial_source':['TRANSFER-010-PREFREEZE-001']}
    }

graph={
 'schema_version':'1.0','project_id':'TCP-retry-after-transfer-001','status':'compiled',
 'tasks':[
   task('CTASK-project-scaffold','TASK-project-scaffold',['REQ-TRIAL-000'],[],
        ['trial-project/pyproject.toml','trial-project/src/retry_after/__init__.py','trial-project/tests/test_retry_after.py'],
        ['evidence/scaffold-complete.txt'],[],[],['evidence/scaffold-complete.txt'],['GATE-TRIAL-000']),
   task('CTASK-retry-after-parser','TASK-retry-after-parser',['REQ-TRIAL-001'],['trial-project/src/retry_after/parser.py'],
        ['trial-project/pyproject.toml','trial-project/src/retry_after/__init__.py','trial-project/tests/test_retry_after.py','evidence/REQ-TRIAL-001.md','evidence/GATE-TRIAL-001.json','evidence/FROZEN-TRIAL-CRITERIA-001.json'],
        ['trial-project/src/retry_after/parser.py','raw-evidence/pytest-after.txt'],
        ['trial-project/src/retry_after/parser.py'],['CTASK-project-scaffold'],['trial-project/tests/test_retry_after.py'],['GATE-TRIAL-001'])
 ],
 'conflict_zones':[],'diagnostics':[],
 'summary':{'task_count':2,'dependency_edge_count':1,'conflict_zone_count':0,'blocking_diagnostic_count':0},
 'graph_hash':''
}
graph['graph_hash']=canon_hash(graph)

# Execution events establish prerequisite done and target ready.
times=['2026-08-24T18:29:00Z','2026-08-24T18:29:01Z','2026-08-24T18:29:02Z','2026-08-24T18:29:03Z','2026-08-24T18:29:04Z','2026-08-24T18:29:05Z']
events=[
 {'event_id':'TEVT-trial001-scaffold-001','graph_hash':graph['graph_hash'],'task_id':'CTASK-project-scaffold','event_time_utc':times[0],'actor_id':'trial-originator','from_state':None,'to_state':'planned','evidence_refs':[],'reason':None},
 {'event_id':'TEVT-trial001-scaffold-002','graph_hash':graph['graph_hash'],'task_id':'CTASK-project-scaffold','event_time_utc':times[1],'actor_id':'trial-originator','from_state':'planned','to_state':'ready','evidence_refs':[],'reason':None},
 {'event_id':'TEVT-trial001-scaffold-003','graph_hash':graph['graph_hash'],'task_id':'CTASK-project-scaffold','event_time_utc':times[2],'actor_id':'trial-originator','from_state':'ready','to_state':'in_progress','evidence_refs':[],'reason':None},
 {'event_id':'TEVT-trial001-scaffold-004','graph_hash':graph['graph_hash'],'task_id':'CTASK-project-scaffold','event_time_utc':times[3],'actor_id':'trial-originator','from_state':'in_progress','to_state':'done','evidence_refs':['evidence/scaffold-complete.txt'],'reason':None},
 {'event_id':'TEVT-trial001-target-001','graph_hash':graph['graph_hash'],'task_id':'CTASK-retry-after-parser','event_time_utc':times[4],'actor_id':'trial-originator','from_state':None,'to_state':'planned','evidence_refs':[],'reason':None},
 {'event_id':'TEVT-trial001-target-002','graph_hash':graph['graph_hash'],'task_id':'CTASK-retry-after-parser','event_time_utc':times[5],'actor_id':'trial-originator','from_state':'planned','to_state':'ready','evidence_refs':[],'reason':None},
]

# All evidence explicitly selected into context closure.
def selectors(*,tasks=None,reqs=None,verify=None,gates=None,kinds=None):
    return {'task_ids':tasks or [],'requirement_ids':reqs or [],'verification_refs':verify or [],'gate_ids':gates or [],'prompt_kinds':kinds or []}
context=[
 {'context_id':'CTX-trial001-pyproject','ref':'trial-project/pyproject.toml','kind':'artifact','critical':True,'selectors':selectors(tasks=['CTASK-retry-after-parser'])},
 {'context_id':'CTX-trial001-init','ref':'trial-project/src/retry_after/__init__.py','kind':'artifact','critical':True,'selectors':selectors(tasks=['CTASK-retry-after-parser'])},
 {'context_id':'CTX-trial001-parser','ref':'trial-project/src/retry_after/parser.py','kind':'artifact','critical':True,'selectors':selectors(tasks=['CTASK-retry-after-parser'])},
 {'context_id':'CTX-trial001-tests','ref':'trial-project/tests/test_retry_after.py','kind':'test','critical':True,'selectors':selectors(verify=['trial-project/tests/test_retry_after.py'])},
 {'context_id':'CTX-trial001-req','ref':'evidence/REQ-TRIAL-001.md','kind':'requirement','critical':True,'selectors':selectors(reqs=['REQ-TRIAL-001'])},
 {'context_id':'CTX-trial001-gate','ref':'evidence/GATE-TRIAL-001.json','kind':'gate','critical':True,'selectors':selectors(gates=['GATE-TRIAL-001'])},
 {'context_id':'CTX-trial001-frozen','ref':'evidence/FROZEN-TRIAL-CRITERIA-001.json','kind':'artifact','critical':True,'selectors':selectors(tasks=['CTASK-retry-after-parser'])},
 {'context_id':'CTX-trial001-prereq','ref':'evidence/scaffold-complete.txt','kind':'execution','critical':True,'selectors':selectors(tasks=['CTASK-project-scaffold'])},
]

inp={
 'schema_version':'1.0','request_id':'PREQ-transfer010-trial001-implementation','candidate_version':'retry-after-utils-0.1.0',
 'prompt_kind':'implementation','compiled_task_graph':graph,'task_id':'CTASK-retry-after-parser',
 'task_contract':{
   'task_id':'CTASK-retry-after-parser',
   'acceptance_criteria':[
      'All seven pytest test functions in trial-project/tests/test_retry_after.py pass.',
      'Only trial-project/src/retry_after/parser.py is changed by the implementation actor.',
      'parse_retry_after returns None rather than raising for missing or malformed values.',
      'parse_retry_after handles non-negative delta-seconds and HTTP-date values as specified in REQ-TRIAL-001.',
      'The implementation adds no non-standard-library dependency.'
   ],
   'critical_obligations':[
      'Do not modify tests, packaging, exports, gates, or frozen criteria.',
      'Do not write outside trial-project/src/retry_after/parser.py.',
      'Do not weaken verification to obtain a pass.',
      'Return missing or malformed Retry-After input as None without raising.'
   ],
   'evidence_requirements':[
      'Preserve the final contents and SHA-256 of trial-project/src/retry_after/parser.py.',
      'Capture the exact pytest command and output for trial-project/tests/test_retry_after.py.',
      'Capture a before/after file-hash inventory proving no unauthorized project file changed.'
   ],
   'blocking_owner_decision_ids':[],
   'frozen_criteria_refs':['FROZEN-TRIAL-CRITERIA-001']
 },
 'context_records':context,'execution_events':events,
 'actor_context':{'implementation_actor_id':'receiver:gpt-5.6-sol:transfer-trial-001','requested_actor_id':'receiver:gpt-5.6-sol:transfer-trial-001'},
 'requested_write_scopes':['trial-project/src/retry_after/parser.py'],'debug_evidence_refs':[]
}

(TRIAL/'compiler-artifacts/compiled-task-graph.json').write_text(json.dumps(graph,indent=2,sort_keys=True)+'\n',encoding='utf-8')
(TRIAL/'compiler-artifacts/prompt-compilation-input.json').write_text(json.dumps(inp,indent=2,sort_keys=True)+'\n',encoding='utf-8')
(TRIAL/'compiler-artifacts/pre-execution-events.jsonl').write_text(''.join(json.dumps(e,sort_keys=True)+'\n' for e in events),encoding='utf-8')

# Use sealed v0.09.2 code.
sys.path.insert(0, str(SEALED/'src'))
from spec_creator.prompt_compiler import compile_prompt, validate_prompt_input, validate_prompt_envelope
from spec_creator.task_compiler import validate_compiled_graph
from spec_creator.task_execution import replay_task_events

graph_errors=validate_compiled_graph(graph,root=SEALED)
input_errors=validate_prompt_input(inp,root=SEALED)
replay=replay_task_events(graph_hash=graph['graph_hash'], task_ids=[t['task_id'] for t in graph['tasks']], events=events, root=SEALED)
env=compile_prompt(inp,root=SEALED)
env_errors=validate_prompt_envelope(env,root=SEALED)
(TRIAL/'compiler-artifacts/prompt-envelope.json').write_text(json.dumps(env,indent=2,sort_keys=True)+'\n',encoding='utf-8')
(TRIAL/'receiver-input/compiled-prompt.txt').write_text(env['prompt_text'] or '',encoding='utf-8')
(TRIAL/'receiver-input/prompt-envelope.json').write_text(json.dumps(env,indent=2,sort_keys=True)+'\n',encoding='utf-8')

# Map every declared source evidence ref to a supplied file when applicable.
evidence_map={
 'REQ-TRIAL-001':'evidence/REQ-TRIAL-001.md',
 'trial-project/tests/test_retry_after.py':'trial-project/tests/test_retry_after.py',
 'GATE-TRIAL-001':'evidence/GATE-TRIAL-001.json',
 'FROZEN-TRIAL-CRITERIA-001':'evidence/FROZEN-TRIAL-CRITERIA-001.json',
 'trial-project/pyproject.toml':'trial-project/pyproject.toml',
 'trial-project/src/retry_after/__init__.py':'trial-project/src/retry_after/__init__.py',
 'trial-project/src/retry_after/parser.py':'trial-project/src/retry_after/parser.py',
 'evidence/REQ-TRIAL-001.md':'evidence/REQ-TRIAL-001.md',
 'evidence/GATE-TRIAL-001.json':'evidence/GATE-TRIAL-001.json',
 'evidence/FROZEN-TRIAL-CRITERIA-001.json':'evidence/FROZEN-TRIAL-CRITERIA-001.json',
 'evidence/scaffold-complete.txt':'evidence/scaffold-complete.txt'
}
(TRIAL/'receiver-input/evidence-map.json').write_text(json.dumps(evidence_map,indent=2,sort_keys=True)+'\n',encoding='utf-8')

# Pre-execution hash inventory over project files.
def file_hashes(root):
    out={}
    for p in sorted(root.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts:
            out[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
    return out
pre_hashes=file_hashes(PROJECT)
(TRIAL/'raw-evidence/project-hashes-before.json').write_text(json.dumps(pre_hashes,indent=2,sort_keys=True)+'\n',encoding='utf-8')

validation={
 'sealed_release_root':str(SEALED.relative_to(CHECKPOINT)),
 'compiled_task_graph_schema_errors':graph_errors,
 'prompt_input_schema_errors':input_errors,
 'execution_replay':replay,
 'prompt_envelope_schema_errors':env_errors,
 'prompt_status':env['status'],
 'prompt_envelope_sha256':env['envelope_hash'],
 'compiled_prompt_text_sha256':hashlib.sha256((env['prompt_text'] or '').encode()).hexdigest(),
}
(TRIAL/'validation/pre-execution-validation.json').write_text(json.dumps(validation,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps(validation,indent=2))
