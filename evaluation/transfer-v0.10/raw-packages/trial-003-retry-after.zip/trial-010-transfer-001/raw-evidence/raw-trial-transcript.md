# Raw Transfer Trial Execution Record

Trial ID: TRANSFER-010-TRIAL-001-RETRY-AFTER
Protocol: TRANSFER-010-PREFREEZE-001
Source Prompt Compiler release: sealed v0.09.2
Receiver context ID: RCX-20260824-GPT56SOL-TRANSFER-001
Prompt kind: implementation
Prompt envelope hash: 443ba189d9f2957b04c35208e3c670235b95a9225d6b061f3623fc67cd5a67f9
Compiled prompt text SHA-256: 9ce8cae913fa5949dbfd32f27b83c8e0e2116942fc09da3b10d3425b3423c234
Graph hash: 1e1e709bb8571803cf1b4172eb2596b230a5cdfe1aa3773cbe92cad24ddc3e20

## Receiving-context conditions

- This receiving ChatGPT context was distinct from the historical context that implemented/evaluated v0.09.2.
- No prior-chat Spec Creator summary was used as execution evidence.
- During task execution after envelope creation, the receiver used the compiled prompt and supplied evidence under `receiver-input/`; it did not consult hidden v0.09.2 implementation-session context.
- The task was a real bounded Python implementation task, not a prompt-compiler benchmark fixture.
- Authorized implementation write scope was exactly `trial-project/src/retry_after/parser.py`.

## Originating task/input

Implement `parse_retry_after` for a small Python utility package. The task had one completed prerequisite (`CTASK-project-scaffold`), one target task in `ready` state (`CTASK-retry-after-parser`), pre-existing tests, frozen criteria, and one authorized source-file write scope. Exact machine input is preserved in `compiler-artifacts/prompt-compilation-input.json`; exact construction provenance is preserved in `raw-evidence/originating-task-builder.py`.

## Pre-execution validation

- Compiled task graph schema/hash validation: PASS (0 diagnostics).
- Prompt-compilation input schema validation: PASS (0 diagnostics).
- Pre-execution event replay: PASS; prerequisite=done, target=ready.
- Prompt envelope schema/hash validation: PASS (0 diagnostics).
- Compiler returned status: `compiled`.

## Exact compiled prompt

Preserved byte-for-byte in `receiver-input/compiled-prompt.txt`.

## Baseline execution evidence

Command: `python -m pytest -q tests/test_retry_after.py`
Result: 7 failed because the target function raised `NotImplementedError`.
Raw output: `raw-evidence/pytest-before.txt`.

## Implementation action

The receiver modified only `trial-project/src/retry_after/parser.py`. No reconstruction/context request was made. No corrective prompt was supplied.

## Completion execution evidence

Command: `python -m pytest -q tests/test_retry_after.py`
Result: 7 passed.
Raw output: `raw-evidence/pytest-after.txt`.

Project file hash comparison: only `src/retry_after/parser.py` changed; unauthorized change count = 0.
Final parser SHA-256: db8675f0c2ebfa0677a80b30da2c7ab27c069c0c7373aec95e37273282753729

## Transfer observations

- Reconstruction requests: 0
- Corrective prompts: 0
- Scope escapes: 0
- Missing-obligation events: 0
- Prerequisite escapes: 0
- Owner-decision escapes: 0
- Verifier/self-certification escape: not applicable to this implementation-kind prompt; no verification prompt was compiled in this one trial.
- Completed: true
- Protocol-required missing fields: 0
- Missing/unavailable required evidence: none observed.

## Determination

The trial is recorded as VALID and COMPLETED. TRANSFER-010-PREFREEZE-001 does not preregister a separate individual-trial PASS/FAIL rule; its PASS-like acceptance is defined only for the aggregate three-trial prefreeze gate. Therefore no individual PASS claim is manufactured here. The aggregate v0.10 transfer gate remains incomplete until three valid trials exist.
