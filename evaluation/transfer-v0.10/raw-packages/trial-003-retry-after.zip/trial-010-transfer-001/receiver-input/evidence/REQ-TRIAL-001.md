# REQ-TRIAL-001 — Retry-After parser

Implement `parse_retry_after(value, *, now=None)` in `trial-project/src/retry_after/parser.py`.

Required behavior:
- `None`, blank, malformed, negative, and non-integer/non-date values return `None` without raising.
- Non-negative decimal delta-seconds return the same integer number of seconds.
- Valid HTTP-date values return the number of whole seconds remaining relative to `now`; past dates clamp to `0`.
- Fractional positive remaining time rounds up to the next whole second.
- When `now` is omitted, use the current UTC time.
- Use Python standard library only.
- Do not modify tests, packaging, exports, or any file outside `trial-project/src/retry_after/parser.py`.
