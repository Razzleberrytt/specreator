from datetime import datetime, timezone

from retry_after import parse_retry_after


def test_none_and_blank_are_missing():
    assert parse_retry_after(None) is None
    assert parse_retry_after("") is None
    assert parse_retry_after("   ") is None


def test_delta_seconds_are_preserved():
    assert parse_retry_after("0") == 0
    assert parse_retry_after("120") == 120
    assert parse_retry_after(" 42 ") == 42


def test_invalid_delta_seconds_do_not_raise():
    assert parse_retry_after("-1") is None
    assert parse_retry_after("1.5") is None
    assert parse_retry_after("abc") is None


def test_http_date_returns_remaining_seconds():
    now = datetime(1994, 11, 6, 8, 49, 0, tzinfo=timezone.utc)
    assert parse_retry_after("Sun, 06 Nov 1994 08:49:37 GMT", now=now) == 37


def test_past_http_date_clamps_to_zero():
    now = datetime(1994, 11, 6, 8, 50, 0, tzinfo=timezone.utc)
    assert parse_retry_after("Sun, 06 Nov 1994 08:49:37 GMT", now=now) == 0


def test_fractional_remaining_time_rounds_up():
    now = datetime(1994, 11, 6, 8, 49, 35, 500000, tzinfo=timezone.utc)
    assert parse_retry_after("Sun, 06 Nov 1994 08:49:37 GMT", now=now) == 2


def test_malformed_http_date_returns_none():
    assert parse_retry_after("not a date") is None
