from __future__ import annotations

from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from math import ceil


def parse_retry_after(value: str | None, *, now: datetime | None = None) -> int | None:
    """Parse an HTTP Retry-After value into whole seconds."""
    if value is None:
        return None

    text = value.strip()
    if not text:
        return None

    if text.isascii() and text.isdigit():
        return int(text)

    try:
        retry_at = parsedate_to_datetime(text)
    except (TypeError, ValueError, OverflowError):
        return None
    if retry_at is None:
        return None

    if retry_at.tzinfo is None:
        retry_at = retry_at.replace(tzinfo=timezone.utc)
    else:
        retry_at = retry_at.astimezone(timezone.utc)

    if now is None:
        now_utc = datetime.now(timezone.utc)
    elif now.tzinfo is None:
        now_utc = now.replace(tzinfo=timezone.utc)
    else:
        now_utc = now.astimezone(timezone.utc)

    remaining = (retry_at - now_utc).total_seconds()
    if remaining <= 0:
        return 0
    return ceil(remaining)
